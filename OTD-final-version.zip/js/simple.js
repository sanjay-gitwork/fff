
$('input[name="dates"]').daterangepicker();