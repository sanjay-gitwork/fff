$('input[name="dates"]').daterangepicker();

